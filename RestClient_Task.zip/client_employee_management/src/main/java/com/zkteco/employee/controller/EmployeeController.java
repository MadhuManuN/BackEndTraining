package com.zkteco.employee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.employee.dto.ClientDto;
import com.zkteco.employee.service.EmployeeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/employee")
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	@PostMapping("/")
	public Object postClientEmpDetails(@Valid @RequestBody ClientDto clientDto) {
		return service.postClientEmpDetails(clientDto);
	}

	@GetMapping("/list")
	public Object getClientEmpDetails() {
		return service.getClientDetails();
	}

	@GetMapping("/{id}")
	public Object getClientEmpById(@PathVariable(value = "id") String id) {
		return service.getClientEmpById(id);
	}

	@DeleteMapping("/{id}")
	public ClientDto deleteClientEmpById(@PathVariable("id") String id) {
		return service.deleteClientEmpById(id);
	}

	@PutMapping("/{id}")
	public ClientDto updateClientEmpById(@PathVariable("id") String id, @RequestBody ClientDto clientDto) {
		return service.updateClientEmpById(id, clientDto);
	}
	
	@PostMapping("/student")
	public Object postStudDetails(@Valid @RequestBody ClientDto clientDto) {
		return service.postStudDetails(clientDto);
	}
	@GetMapping("/student/list")
	public Object getStudDetails() {
		return service.getStudDetails();
	}
	@GetMapping("/student/{id}")
	public Object getStudById(@PathVariable(value = "id") String id) {
		return service.getStudById(id);
	}
	
	@DeleteMapping("/student/{id}")
	public String deleteStudById(@PathVariable("id") String id) {
		return service.deleteStudById(id);
	}
	@PutMapping("/student/{id}")
	public String updateStudById(@PathVariable("id") String id, @RequestBody ClientDto clientDto) {
		return service.updateStudById(id, clientDto);
	}

}
