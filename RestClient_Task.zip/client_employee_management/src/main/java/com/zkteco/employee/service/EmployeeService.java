package com.zkteco.employee.service;

import org.springframework.stereotype.Service;

import com.zkteco.employee.dto.ClientDto;

import jakarta.validation.Valid;

@Service
public interface EmployeeService {

	public Object getClientDetails();

	public Object getClientEmpById(String id);

	public Object postClientEmpDetails(@Valid ClientDto clientDto);

	public ClientDto deleteClientEmpById(String id);

	public ClientDto updateClientEmpById(String id, ClientDto clientDto);

	public Object postStudDetails(@Valid ClientDto clientDto);

	public Object getStudDetails();

	public Object getStudById(String id);

	public String deleteStudById(String id);

	public String updateStudById(String id, ClientDto clientDto);

}
