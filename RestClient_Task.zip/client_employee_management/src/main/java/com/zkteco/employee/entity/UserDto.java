package com.zkteco.employee.entity;


import lombok.Data;

@Data
public class UserDto {
	
	private String userId;
	
	private String firstName;
	
	private String lastName;
	
	private String gender;
	
	private String userEmailId;
	
	private String phoneNumber;
	
	private String password;
	
	private String dateOfBirth;
	
	private Boolean profilePhoto;
	
	private String createDate;
	
	private String updateDate;
}
