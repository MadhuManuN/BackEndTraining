package com.zkteco.employee.serviceImpl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.zkteco.employee.dto.ClientDto;
import com.zkteco.employee.service.EmployeeService;

import jakarta.validation.Valid;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private RestTemplate restTemplate;
	private String base_url="http://10.10.21.45:8080/employee";

	@Override
	public Object getClientDetails() {
		HttpHeaders headers=new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity=new HttpEntity<>(headers);
		return restTemplate.exchange(base_url+"/getAll", HttpMethod.GET, entity, Object[].class);
//		return restTemplate.getForObject(base_url+"/getAll", Object[].class);
	}

	@Override
	public Object getClientEmpById(String id) {
		HttpHeaders headers=new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Object> entity=new HttpEntity<>(headers);
		return restTemplate.exchange(base_url+"/"+ id, HttpMethod.GET, entity, Object.class).getBody();
//		return restTemplate.getForObject(base_url+"/"+ id, Object.class);
	}

	@Override
	public Object postClientEmpDetails(@Valid ClientDto clientDto) {
		HttpHeaders headers=new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<ClientDto> entity=new HttpEntity<ClientDto>(clientDto,headers);
		return restTemplate.exchange(base_url, HttpMethod.POST, entity, Object.class).getBody();
//		return restTemplate.postForObject(base_url, clientDto, Object.class);
	}

	@Override
	public ClientDto deleteClientEmpById(String id) {
		HttpHeaders headers=new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<ClientDto> entity=new HttpEntity<>(headers);
		return restTemplate.exchange(base_url+"/"+ id, HttpMethod.DELETE, entity, ClientDto.class).getBody();
//		restTemplate.delete(base_url+"/"+ id);
//		return "Data Deleted Successfully";
	}

	@Override
	public ClientDto updateClientEmpById(String id, ClientDto clientDto) {
		HttpHeaders headers=new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<ClientDto> entity=new HttpEntity<>(clientDto,headers);
		return restTemplate.exchange(base_url+"/"+ id, HttpMethod.PUT, entity, ClientDto.class).getBody();
//		restTemplate.put(base_url+"/"+ id, clientDto);
//		return "Client Data Updated Successfully";
	}

	@Override
	public Object postStudDetails(@Valid ClientDto clientDto) {
		return restTemplate.postForObject(base_url, clientDto, Object.class);
	}

	@Override
	public Object getStudDetails() {
		return restTemplate.getForObject(base_url+"/getAll", Object[].class);
	}

	@Override
	public Object getStudById(String id) {
		return restTemplate.getForObject(base_url+"/"+ id, Object.class);
	}

	@Override
	public String deleteStudById(String id) {
		restTemplate.delete(base_url+"/"+ id);
		return "Data Deleted Successfully";
	}

	@Override
	public String updateStudById(String id, ClientDto clientDto) {
		restTemplate.put(base_url+"/"+ id, clientDto);
		return "Client Data Updated Successfully";
	}

}
