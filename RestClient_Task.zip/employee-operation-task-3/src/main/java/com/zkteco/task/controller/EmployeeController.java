package com.zkteco.task.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.zkteco.task.entity.Employee;
import com.zkteco.task.entity.Result;
import com.zkteco.task.exception.ResourceNotFoundException;
import com.zkteco.task.service.EmployeeService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api")
public class EmployeeController {

	@Autowired
	private EmployeeService service;

	private final Logger logger = LoggerFactory.getLogger(EmployeeController.class);

	@PostMapping("/employee")
	public Result saveEmployee(@Valid @RequestBody Employee employee, HttpServletRequest request) {
		// convert DTO to entity
		logger.info("Inside save Employee Method");
		return service.saveEmployee(employee, request);
	}

	@PostMapping("/employee/batch")
	public List<Result> saveMultipleData(@Valid @RequestBody List<Employee> employee, HttpServletRequest request) {
		return service.saveAllData(employee, request);
	}

	@GetMapping("/employee/all")
	public List<Employee> fetchAllData() {
		logger.info("Inside Fetch Employee Method");
		return service.fetchAllData();
	}

	@GetMapping("/employee/{id}")
	public Result fetchById(@PathVariable(value = "id") String employeeId, HttpServletRequest request)
			throws ResourceNotFoundException {
		logger.info("Inside FetchBy ID Employee Method");
		return service.fetchById(employeeId, request);
	}

	@GetMapping("/employee/employeeEmailId")
	public Result fetchByEmail(@RequestParam String employeeEmailId, HttpServletRequest request)
			throws ResourceNotFoundException {
		logger.info("Inside FetchBy EmailId Employee Method");
		return service.fetchByEmail(employeeEmailId, request);
	}

	@GetMapping("/employee/phoneNumber")
	public Result fetchByPhone(@RequestParam String phoneNumber, HttpServletRequest request)
			throws ResourceNotFoundException {
		logger.info("Inside FetchBy phone number Employee Method");
		return service.fetchByPhone(phoneNumber, request);
	}

	@GetMapping("/employee/{fromDate}/{toDate}")
	public List<Employee> fetchByDate(@PathVariable(value = "fromDate") String fromDate,
			@PathVariable(value = "toDate") String toDate, HttpServletRequest request)
			throws ResourceNotFoundException {
		logger.info("Inside FetchBy Date Employee Method");
		return service.fetchByDate(fromDate, toDate, request);
	}

	@DeleteMapping("/employee/{id}")
	public Result deleteById(@PathVariable("id") String employeeId, HttpServletRequest request) {
		logger.info("Inside Delete by ID Method");

		return service.deleteById(employeeId, request);
	}

	@PutMapping("/employee/{id}")
	public Result updateById(@PathVariable(value = "id") String employeeId, @RequestBody Employee employee,
			HttpServletRequest request) {
		logger.info("Inside Update By ID Employee Method");
		return service.updateById(employeeId, employee, request);
	}
	
}
