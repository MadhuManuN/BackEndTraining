package com.zkteco.task.dto;

import java.time.LocalDate;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClientDto {
	
	private String employeeId;
	private String firstName;
	private String lastName;
	private String gender;
	private String emailId;
	private String phoneNumber;
	private String password;
	private Date dateOfBirth;
	private String profilePhoto;
	private LocalDate empCreatedDate;
	private LocalDate empUpdatedDate;
	private ClientDeptDto department;
	private ClientDesigDto designation;


}
