package com.zkteco.task.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zkteco.task.entity.Designation;
import com.zkteco.task.entity.Result;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@Service
public interface DesignationService {

	Result saveDepartment(@Valid Designation designation,HttpServletRequest request);

	List<Result> saveAllData(@Valid List<Designation> designation,HttpServletRequest request);

	List<Designation> fetchAllData();

	Result fetchById(String desigId,HttpServletRequest request);

	Result deleteById(String desigId,HttpServletRequest request);

	Result updateById(String desigId, Designation designation,HttpServletRequest request);

}
