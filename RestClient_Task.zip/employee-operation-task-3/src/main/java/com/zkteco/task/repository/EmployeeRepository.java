package com.zkteco.task.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.zkteco.task.entity.Employee;
import com.zkteco.task.entity.UserDto;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, String> {
	
	public Employee findByEmployeeEmailId(String employeeEmailId);

	public Employee findByphoneNumber(String phoneNumber);
	
	public List<Employee> findByCreateDate(String createDate);
	
}
