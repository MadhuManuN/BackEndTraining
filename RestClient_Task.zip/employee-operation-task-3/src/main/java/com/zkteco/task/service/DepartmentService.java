package com.zkteco.task.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.zkteco.task.entity.Department;
import com.zkteco.task.entity.Result;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;

@Service
public interface DepartmentService {

	public Result saveDepartment(@Valid Department department,HttpServletRequest request);

	public Result deleteById(String deptId,HttpServletRequest request);

	public List<Result> saveAllData(@Valid List<Department> department,HttpServletRequest request);

	public List<Department> fetchAllData();

	public Result fetchById(String deptId,HttpServletRequest request);

	public Result updateById(String deptId, Department department,HttpServletRequest request);

}
