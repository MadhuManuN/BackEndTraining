package com.zkteco.task.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClientDeptDto {
	
	private String deptId;
	private String deptName;
	private String deptCode;
	private String deptCreatedDate;
	private String deptUpdatedDate;

}
