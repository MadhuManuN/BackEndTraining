package com.zkteco.task.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClientDesigDto {
	
	private String desgId;
	private String desgName;
	private String desgCode;
	private String desgCreatedDate;
	private String desgUpdatedDate;

}
