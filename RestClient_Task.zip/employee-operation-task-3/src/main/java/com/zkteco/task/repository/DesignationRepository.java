package com.zkteco.task.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.zkteco.task.entity.Designation;

@Repository
public interface DesignationRepository extends JpaRepository<Designation, String>{
	public Designation findByDesigName(String desigName);
    
    public Designation findByDesigCode(String desigCode);
}
