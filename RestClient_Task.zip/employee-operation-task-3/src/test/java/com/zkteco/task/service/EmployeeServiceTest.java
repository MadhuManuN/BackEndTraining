package com.zkteco.task.service;

import static org.junit.jupiter.api.Assertions.*;


import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.zkteco.task.entity.Department;
import com.zkteco.task.entity.Designation;
import com.zkteco.task.entity.Employee;
import com.zkteco.task.entity.Result;

import com.zkteco.task.repository.EmployeeRepository;

import jakarta.servlet.http.HttpServletRequest;
@SpringBootTest
class EmployeeServiceTest {
	
	@Autowired
	private EmployeeService employeeService;
	
	@MockBean
	private EmployeeRepository employeeRepository;

	@Autowired
    HttpServletRequest request;
	
	Result result=null;
	
	Optional<Employee> employee1;
	
	@BeforeEach
	void setUp() throws Exception {
		
		Department department=Department.builder()
				.deptId("1")
				.deptName("R&D")
				.deptCode("abc123")
				.createDate("2023-03-15")
				.updateDate("2023-03-22")
				.build();
		Designation designation=Designation.builder()
				.desigId("1")
				.desigName("java")
				.desigCode("pqr123")
				.createDate("2023-03-15")
				.updateDate("2023-03-22")
				.build();
		this.employee1=Optional.of(Employee.builder()
				.employeeId("1")
				.firstName("madhu")
				.lastName("manu")
				.gender("M")
				.employeeEmailId("madhu123@gmail.com")
				.phoneNumber("+91-9874561231")
				.password("Wypuyh265")
				.dateOfBirth("1/06/2023")
				.profilePhoto(true)
				.createDate("2023-03-15")
				.updateDate("2023-03-21")
				.department(department)
				.designation(designation)
				.build());
//		result=new Result("I100", "Success", employee1.get());
		Mockito.when(employeeRepository.findById(employee1.get().getEmployeeId())).thenReturn(employee1);
	}

	@Test
	public void getEmployeeById() throws Exception {
		
		Result entity=employeeService.fetchById("1", this.request);
		System.out.println(entity);
		assertEquals(employee1.get(), entity.getData());
	}

}
