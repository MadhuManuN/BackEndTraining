package com.zkteco.task;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeOperationTask3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
