package com.zkteco.student.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class StudentConfiguration {

	@Bean
	public WebClient.Builder webClientBuilder() {
		return WebClient.builder();
	}

}
