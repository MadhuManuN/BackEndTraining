package com.zkteco.student.serviceImpl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.zkteco.student.dto.ClientDto;
import com.zkteco.student.dto.ResultDto;
import com.zkteco.student.service.StudentService;

import jakarta.validation.Valid;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private WebClient.Builder webClientBuilder;
	@Value("${base_url}")
	private String base_url;

	@Override
	public Mono<ResultDto> postStudDetails(@Valid ClientDto clientDto) {
		return webClientBuilder.build()
				.post()
		        .uri(base_url)
		        .body(Mono.just(clientDto), ClientDto.class)
		        .retrieve()
		        .bodyToMono(ResultDto.class);
//		HttpHeaders headers=new HttpHeaders();
//		headers.setContentType(MediaType.APPLICATION_JSON);
//		HttpEntity<ClientDto> entity=new HttpEntity<>(clientDto,headers);
//		return restTemplate.exchange(base_url, HttpMethod.POST, entity, Object.class).getBody();
//		return restTemplate.postForObject(base_url, clientDto, Object.class);
	}

	@Override
	public Flux<ResultDto> getStudDetails() {
		return webClientBuilder.build()
				 .get()
				 .uri(base_url)
				 .retrieve()
				 .bodyToFlux(ResultDto.class);
//		HttpHeaders headers=new HttpHeaders();
//		headers.setContentType(MediaType.APPLICATION_JSON);
//		HttpEntity<Object> entity=new HttpEntity<>(headers);
//		return (List<ResultDto>) restTemplate.exchange(base_url, HttpMethod.GET, entity, ResultDto.class);
//		return (List<ResultDto>) restTemplate.getForObject(base_url, ResultDto.class);
	}

	@Override
	public ResultDto getStudById(String id) {
		return webClientBuilder.build()
		 .get()
		 .uri(base_url+"/"+ id)
		 .retrieve()
		 .bodyToMono(ResultDto.class)
		 .block();
//		HttpHeaders headers=new HttpHeaders();
//		headers.setContentType(MediaType.APPLICATION_JSON);
//		HttpEntity<Object> entity=new HttpEntity<>(headers);
//		return restTemplate.exchange(base_url+"/"+ id, HttpMethod.GET, entity, ResultDto.class).getBody();
//		return restTemplate.getForObject(base_url+"/"+ id, Object.class);
	}

	@Override
	public Mono<ResultDto> deleteStudById(String id) {
		return webClientBuilder.build()
				.delete()
				.uri(base_url+"/"+ id)
				.retrieve()
				.bodyToMono(ResultDto.class);
//		HttpHeaders headers=new HttpHeaders();
//		headers.setContentType(MediaType.APPLICATION_JSON);
//		HttpEntity<ClientDto> entity=new HttpEntity<>(headers);
//		return restTemplate.exchange(base_url+"/"+ id, HttpMethod.DELETE, entity, ClientDto.class).getBody();
//		restTemplate.delete(base_url+"/"+ id);
//		return "Data Deleted Successfully";
		
	}
	
	@Override
	public Mono<ResultDto> updateStudById(String id, ClientDto clientDto) {
		return webClientBuilder.build()
				.put()
				.uri(base_url+"/"+ id)
				.body(Mono.just(clientDto), ClientDto.class)
				.retrieve()
				.bodyToMono(ResultDto.class);
//		HttpHeaders headers=new HttpHeaders();
//		headers.setContentType(MediaType.APPLICATION_JSON);
//		HttpEntity<ClientDto> entity=new HttpEntity<>(clientDto,headers);
//		return restTemplate.exchange(base_url+"/"+ id, HttpMethod.PUT, entity, ClientDto.class).getBody();
//		restTemplate.put(base_url+"/"+ id, clientDto);
//		return "Client Data Updated Successfully";
	}

}
